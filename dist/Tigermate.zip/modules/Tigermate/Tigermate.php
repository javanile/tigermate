<?php

class Tigermate
{

}